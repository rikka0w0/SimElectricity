REM Include files:
REM     ./AMD/Include
REM     ./SuiteSparse_config
REM     ./UMFPACK/Include
REM 
REM Libraries:
REM     ./library/native/libumfpack.lib  (main library)
REM     ./library/native/libamd.lib
REM     ./library/native/libsuitesparseconfig.lib
REM (supports)
REM     ./library/native/libcholomod.lib
REM     ./library/native/libcolamd.lib
REM     ./library/native/libccolamd.lib
REM     ./library/native/libcamd.lib
REM     ./library/native/libgcc.lib      (if necessary)

REM Sample build command:

cl -MD -I../../AMD/Include -I../../SuiteSparse_config -I../../UMFPACK/Include umfpack_simple.c *.lib