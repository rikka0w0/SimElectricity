package simElectricity.API;


/** When a player is going to see the tileEntity, onWatch() will be fired*/
public interface IUpdateOnWatch {
	void onWatch();
}
