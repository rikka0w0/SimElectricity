package simElectricity.API;


public interface IEnergyNetUpdateHandler {
    /**
     * This function is called when the energy net updates
     */
    void onEnergyNetUpdate();
}
